export class AnnotationsModel {
    constructor(
        public docId: String,
        public epubCfis: Array<string>
    ) {
    }
}
