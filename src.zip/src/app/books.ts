export const Books=[
    {
        id: 1,
        path:"/assets/ebook/book1/book1.epub",
        title: 'Enzymes of Energy Technology',
        image:"/assets/ebook/book1/book1.jpg"
        }, 
        {
        id: 2,
        path:"/assets/ebook/book2/book2.epub",
        title: 'When Peace Is Not Enough: How the Israeli Peace Camp Thinks about Religion, Nationalism, and Justice',
        image:"/assets/ebook/book2/book2.png"
        }, 
        {
        id: 3,
        path:"/assets/ebook/book3/book3.epub",
        title: 'Let\'s Talk About Feeling Inferior',
        image:"/assets/ebook/book3/book3.png"
        }
]